import UIKit

func CheckSign(firstNumber: Int, secondNumber: Int) -> String {
    if (firstNumber ^ secondNumber) < 0 {
        return "\(firstNumber) and \(secondNumber) have opposite signs"
    } else {
        return "\(firstNumber) and \(secondNumber) have the same signs"
    }
}

print(CheckSign(firstNumber: -2, secondNumber: -4))

// || -> OR -> 1 OR 1 = 1, 0 OR 1 = 1, 0 OR 0 = 0
// & -> And -> 1 AND 1 = 1, 0 And 1 = 0, 0 And 0 = 0
// ! -> Not -> !0 = 1, !1 = 0
// ^ -> XOR -> 1 XOR 1 = 0, 0 XOR 1 = 1, 0 XOR 0 = 0

